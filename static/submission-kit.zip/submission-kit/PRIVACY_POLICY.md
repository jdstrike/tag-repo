# Privacy Policy: the Adecco Group UTM Builder

Effective date: 2026-06-02
Operated by: the Adecco Group, Global Digital Marketing

## What we collect

The Adecco Group UTM Builder is a marketing tool that helps employees generate tracking links for campaigns. We collect and process the following data:

1. **Account data** (only if you create an account): username, work email, full name, password hash. Stored in our database on adeccogroup-controlled infrastructure.

2. **Link metadata** (when you build a link): destination URL, UTM parameters (source, medium, campaign, term, content, id), brand and country, additional dimensions you fill (agency, targeting, segmentation, asset type), the generated short URL code, and your account email as the link owner.

3. **Click data** (when someone clicks one of the short links you generated): timestamp, IP address, browser User-Agent, referring page URL. Used to count clicks and provide aggregate performance reporting.

4. **Browser extension specific**: when you open the extension popup, the URL of your currently active tab is read so it can be pre-filled as the destination. This URL is sent to the backend only when you explicitly click "Generate link". It is not collected, stored, or used otherwise.

## What we don't collect

- No third-party analytics or trackers in the extension or web app
- No telemetry, no usage analytics sent to any third party
- No data shared with external services beyond what you explicitly send (the generated link itself, and the visitor's click data when the short URL is followed)

## How we use it

- Account data: to authenticate you and attribute the links you build
- Link metadata: to provide the link-building service, audit trail, and the admin approval workflow
- Click data: to provide aggregate performance metrics in the Performance Dashboard
- All data is processed on the Adecco Group's behalf, on infrastructure controlled by the Adecco Group

## Retention

- Account data: kept while your account is active. You can request deletion via the admin.
- Link metadata: kept indefinitely as part of the marketing campaign record. Individual links can be deleted by the admin.
- Click data: kept for 90 days in detailed form, then aggregated.

## Your rights

If you are an Adecco Group employee, you can request access to your data, correction, or deletion via the admin (Johannes Schatt, johannes.schatt@adeccogroup.com). External visitors whose click data is captured can request deletion of that data by emailing privacy@adeccogroup.com with the short link code in question.

## Lawful basis (GDPR)

For employees: legitimate interest in operating internal marketing tools and tracking campaign performance, balanced with employee rights.
For visitors who click short links: legitimate interest in measuring marketing effectiveness, with GDPR-compliant data minimization (IP addresses are partially anonymized after 30 days).

## Contact

Privacy questions or requests: johannes.schatt@adeccogroup.com (or privacy@adeccogroup.com)
Data Protection Officer: as designated by the Adecco Group corporate DPO function

## Updates

This policy may be updated. Material changes will be announced via in-app notice. The current version is always at https://utm.tag-repo.com/privacy.
