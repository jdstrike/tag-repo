# Microsoft Edge Add-ons Submission Kit

This kit contains everything you need to submit "the Adecco Group UTM Builder" extension to the Microsoft Edge Add-ons store via Microsoft Partner Center.

## Files in this kit

| File | What it is | Where it goes |
|---|---|---|
| `extension-package.zip` | The actual extension code (unzip and re-zip the inner folder if Partner Center complains) | Upload as the extension package |
| `store-assets/store-logo-300.png` | Store logo, 300×300 | Listing → Store logo |
| `store-assets/store-logo-150.png` | Smaller logo, 150×150 | Listing → Small logo (if asked) |
| `store-assets/store-logo-56.png` | Tile icon, 56×56 | Listing → Tile / favicon-style |
| `store-assets/screenshot-1-overview.png` | 1366×768 screenshot showing extension popup in context | Listing → Screenshots (at least 1 required, up to 10) |

## Account setup (one-time, 15-20 min)

1. **Go to** https://partner.microsoft.com/dashboard/microsoftedge/
2. **Sign in** with a Microsoft account. Use your @adeccogroup.com email if you have an Azure AD / M365 account, otherwise use any Microsoft account.
3. **Accept** the Microsoft Edge Add-ons developer agreement.
4. **Verify your account**: Microsoft will ask for your name, address, optionally company details. Approval takes anywhere from minutes to 2-3 business days for first-time developers. No fee.
5. Once verified, you'll see the dashboard with a "Create new extension" button.

## Submission walkthrough

1. **Dashboard → Microsoft Edge → Overview → "Create new extension"**
2. **Step 1: Package upload**
   - Upload `extension-package.zip`. Partner Center extracts it and validates manifest.json
   - If it errors about "zip should not have a wrapper folder": unzip locally, then re-zip the CONTENTS (not the parent folder)
3. **Step 2: Availability**
   - **Visibility**: choose **Hidden** if you only want Adecco employees to install via direct link (recommended for internal tools), or **Public** if anyone can find it.
   - **Markets**: select All, or specific countries (DE, CH, GB, US, FR, IT, AT, BE, NL, etc.)
   - **Pricing**: Free
4. **Step 3: Properties**
   - **Category**: Productivity
   - **Privacy policy URL**: `https://utm.tag-repo.com/privacy`
   - **Support URL**: `https://utm.tag-repo.com/support`
   - **Website**: `https://utm.tag-repo.com/`
5. **Step 4: Store listing** (per language; English is enough for v1)
   - **Display name**: `the Adecco Group UTM Builder`
   - **Short description (200 chars)**:
     > Build GA4-ready UTM tracking links from any browser tab. Two clicks for campaign attribution across Adecco Group marketing channels.
   - **Description (full)**: see "STORE_LISTING_DESCRIPTION.md" below
   - **Search keywords**: utm, marketing, ga4, tracking, campaign, link, builder, adecco, akkodis, lhh, attribution
   - **Logo (300×300)**: upload `store-assets/store-logo-300.png`
   - **Screenshots**: upload `store-assets/screenshot-1-overview.png`
6. **Step 5: Submission**
   - **Notes for the certification team**: see "REVIEWER_NOTES.md" below
   - Click **Submit**
7. **Review**: typically 1-3 business days. You'll get an email with approval or required changes.

## Files included for your reference

### STORE_LISTING_DESCRIPTION.md
Full description for the listing page.

### REVIEWER_NOTES.md
Notes for the Microsoft certification team that help them understand and test the extension faster.

### PRIVACY_POLICY.md
Reference copy of the privacy policy hosted at /privacy.

## Visibility recommendations

For an internal Adecco tool, the **Hidden** visibility is the right choice:
- The store URL is shareable (you can post it on Confluence, send via email)
- It does NOT appear in search results
- Anyone with the URL can install
- Adecco employees won't have to wade through unrelated extensions
- Non-employees who somehow find it can install but will see "Sign in required" and can't use it

You can switch from Hidden to Public later if you decide to open it up.

## After approval

- The extension gets a permanent URL like: `https://microsoftedge.microsoft.com/addons/detail/<your-extension-id>`
- Update the **/extension** page on the tool with a one-click "Install from Edge Add-ons store" button
- Update the install instructions to "1-click via Edge Add-ons" instead of the manual unzip flow

## Optional: Chrome Web Store

You can also submit to the Chrome Web Store. The process is similar:
- Account: https://chrome.google.com/webstore/devconsole/
- One-time fee: $5
- Visibility options: Public / Unlisted / Private (Google Workspace org-wide)
- Same package works (Chrome MV3 = Edge MV3)

Edge is recommended first because it's free, and many enterprise users have Edge as their default browser.
