# Store Listing Description

Build GA4-ready UTM tracking links from any browser tab. The Adecco Group UTM Builder extension is the companion to the internal Adecco Group marketing UTM builder hosted at utm.tag-repo.com.

## What it does

When you click the extension icon, the current tab's URL becomes the destination for a new UTM tracking link. Pick your campaign, source, and medium from the dropdowns; the extension generates a long URL with all UTM parameters and a branded short URL on the utm.tag-repo.com domain. Both are copy-able with a single click.

## Who it's for

The Adecco Group Global Digital Marketing team and country marketing leads who build UTM tracking links daily for Adecco, LHH, Akkodis, Pontoon, and the Adecco Group umbrella brand. The extension eliminates the tab-switching dance: instead of leaving your active page to open the UTM builder, paste the URL, fill the form, and copy back, you stay on the page and the URL is auto-filled.

## Key features

- **Two-click campaign attribution**: pick campaign + source + medium, generate
- **GA4-validated combinations**: the extension enforces the same conditional dependencies as the web tool, so you never produce a link that lands in "Unassigned" in your GA4 reports
- **Branded short URLs**: utm.tag-repo.com/s/abc123 instead of the original long URL
- **Auto-tagged with your email**: every link is attributed to the logged-in user for accountability and reporting
- **Single sign-on**: the extension uses the same browser session as the web tool; no separate credentials
- **TAG brand-compliant**: typography, colors, and the Adecco Group lockup match the corporate brand standards

## Privacy

The extension reads only the URL of the active tab when you click the extension icon. It talks exclusively to utm.tag-repo.com over HTTPS. No third-party trackers, no telemetry, no data leaves the Adecco Group infrastructure. Source code is unminified and auditable.

## Required permissions

- **activeTab**: read the URL of the active tab when you open the popup. Pre-fills the destination field.
- **storage**: remembers your last-used source and medium choices.
- **clipboardWrite**: makes the "Copy" buttons actually copy.
- **host_permissions for utm.tag-repo.com**: enables API calls to the builder backend.

## Support

Issues, questions, or feature requests: contact the Adecco Group Global Digital Marketing team or reply to any of the campaign notification emails from utm.tag-repo.com.

## Internal use note

This extension is built for Adecco Group employees. It requires a valid sign-in to utm.tag-repo.com to function. External users will see a "Sign in required" prompt and cannot generate links.
