# Notes for the Microsoft Edge Add-ons certification team

Thank you for reviewing this submission. Here's what you need to know to test the extension efficiently.

## Test account

The extension requires sign-in to the backend at utm.tag-repo.com to function. For testing:

- Test username: `reviewer.test`
- Test password: please contact the developer (Johannes Schatt, johannes.schatt@adeccogroup.com) to receive a temporary reviewer account, or use the self-signup at https://utm.tag-repo.com/signup with any email
- Or visit https://utm.tag-repo.com/signup with any email to create a temporary test account

## Functionality walkthrough

1. Install the extension; pin it to the toolbar.
2. Click the extension icon on any tab. If not signed in, you'll see "Sign in required". Click the button to open utm.tag-repo.com in a new tab.
3. Sign in with the test account (or sign up at /signup).
4. Return to the original tab; click the extension icon again. The builder appears with the current tab URL auto-filled.
5. Choose a campaign (e.g. `pride`), a source (e.g. `linkedin`), and a medium (e.g. `sponsored`). The medium dropdown filters based on the source selection.
6. Click "Generate link". The popup shows a long URL with UTM parameters and a branded short URL on utm.tag-repo.com.
7. Click "Copy" on either to copy to clipboard.

## Permissions justification

- **activeTab**: required to read the URL of the user's current tab so it can be used as the destination of the UTM tracking link. Read only when the user explicitly clicks the extension icon.
- **storage**: stores user preferences (last-used source / medium) locally for convenience. No data is synced or shared.
- **clipboardWrite**: enables the "Copy" buttons to write the generated URL to the clipboard.
- **host_permissions for https://utm.tag-repo.com/***: the extension's backend; required for API calls to build URLs and fetch dropdown values.

## Data handling

- The active tab URL is sent to https://utm.tag-repo.com/api/build only when the user clicks "Generate link".
- The user's authenticated session cookie is included for backend authorization.
- No third-party services are contacted by the extension.
- No analytics, no telemetry, no data collected beyond what is needed to construct the tracking URL.

## Privacy policy

Available at https://utm.tag-repo.com/privacy

## Source code

All code in the package is human-readable, unminified, and well-commented:
- `manifest.json`: extension manifest, Manifest V3
- `popup.html`: the user interface (static HTML + inline CSS)
- `popup.js`: the application logic (~150 lines, no external libraries, no minification)
- `icon-*.png`: extension icons at standard sizes (16, 32, 48, 128)

## Contact for questions

Johannes Schatt, VP Global Digital Marketing, the Adecco Group
johannes.schatt@adeccogroup.com

Thanks for your time. Happy to provide additional information.
