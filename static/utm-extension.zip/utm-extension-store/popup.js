const API_BASE = "https://utm.tag-repo.com";

const $ = (s) => document.querySelector(s);
const signedOut = $("#signedOut");
const builder = $("#builder");
const msg = $("#msg");
const result = $("#result");

let currentTabUrl = "";
let smMap = {};
let userInfo = null;

async function fetchJson(path, opts = {}) {
  opts.credentials = "include";
  opts.headers = opts.headers || {};
  opts.headers["Accept"] = "application/json";
  const r = await fetch(API_BASE + path, opts);
  return { ok: r.ok, status: r.status, json: r.status === 204 ? null : await r.json().catch(() => null) };
}

async function init() {
  // Read current tab
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tabs[0]) {
    currentTabUrl = tabs[0].url || "";
    $("#currentUrl").textContent = currentTabUrl.length > 60 ? currentTabUrl.slice(0, 60) + "…" : currentTabUrl;
  }

  // Try to fetch authenticated session
  const me = await fetchJson("/api/me");
  if (!me.ok || !me.json || !me.json.signed_in) {
    showSignedOut();
    return;
  }
  userInfo = me.json;
  $("#userInfo").textContent = `Signed in: ${userInfo.email || userInfo.username || "user"}`;
  showBuilder();
  await loadDropdowns();
}

function showSignedOut() {
  signedOut.style.display = "block";
  builder.style.display = "none";
}
function showBuilder() {
  signedOut.style.display = "none";
  builder.style.display = "block";
}

$("#openSigninBtn").addEventListener("click", () => {
  chrome.tabs.create({ url: API_BASE + "/signin" });
});
$("#recheckBtn").addEventListener("click", () => init());
$("#openWebBtn").addEventListener("click", (e) => { e.preventDefault(); chrome.tabs.create({ url: API_BASE + "/" }); });

async function loadDropdowns() {
  // Load /api/dropdowns - a single endpoint that returns campaigns + sources + mediums + gbus + countries
  const r = await fetchJson("/api/dropdowns");
  if (!r.ok || !r.json) { msg.innerHTML = '<div class="err">Could not load dropdowns. Are you signed in?</div>'; return; }
  const d = r.json;
  // Campaigns
  const camp = $("#campaignSel");
  camp.innerHTML = '<option value="">Choose campaign</option>' + (d.campaigns || []).map(c => `<option value="${c.name}">${c.name}</option>`).join("");
  // Sources
  $("#sourceSel").innerHTML = '<option value="">Choose source</option>' + (d.sources || []).map(s => `<option value="${s}">${s}</option>`).join("");
  // GBUs
  $("#gbuSel").innerHTML = '<option value="">-</option>' + (d.gbus || []).map(g => `<option value="${g.value}">${g.value}</option>`).join("");
  // Countries
  $("#countrySel").innerHTML = '<option value="">-</option>' + (d.countries || []).map(c => `<option value="${c.value}">${c.value}</option>`).join("");
  smMap = d.sm_map || {};
}

$("#sourceSel").addEventListener("change", () => {
  const src = $("#sourceSel").value;
  const med = $("#mediumSel");
  if (!src) { med.disabled = true; med.innerHTML = '<option value="">Pick source first</option>'; return; }
  const allowed = smMap[src] || [];
  med.disabled = false;
  med.innerHTML = '<option value="">Choose medium</option>' + allowed.map(m => `<option value="${m}">${m}</option>`).join("");
});

$("#buildBtn").addEventListener("click", async () => {
  msg.innerHTML = ""; result.style.display = "none";
  const btn = $("#buildBtn"); btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Generating...';
  const payload = {
    destination: currentTabUrl,
    utm_campaign: $("#campaignSel").value,
    utm_source: $("#sourceSel").value,
    utm_medium: $("#mediumSel").value,
    gbu: $("#gbuSel").value,
    country: $("#countrySel").value,
  };
  const r = await fetchJson("/api/build", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  btn.disabled = false; btn.textContent = "Generate link";
  if (!r.ok) { msg.innerHTML = `<div class="err">${(r.json && r.json.error) || "Build failed"}</div>`; return; }
  const j = r.json;
  result.innerHTML = `
    <div class="result-row">
      <b>Short URL</b>
      <code>${j.short_url}</code>
      <button class="copy-btn" data-copy="${j.short_url}">Copy</button>
    </div>
    <div class="result-row">
      <b>Long URL</b>
      <code>${j.long_url}</code>
      <button class="copy-btn" data-copy="${j.long_url}">Copy</button>
    </div>
    ${j.ga4_channel ? `<div class="muted">GA4 channel: <b>${j.ga4_channel}</b></div>` : ""}
  `;
  result.style.display = "block";
  result.querySelectorAll(".copy-btn").forEach(btn => {
    btn.addEventListener("click", async () => {
      await navigator.clipboard.writeText(btn.dataset.copy);
      const orig = btn.textContent; btn.textContent = "Copied"; setTimeout(() => btn.textContent = orig, 1200);
    });
  });
  msg.innerHTML = '<div class="ok">Link generated. Ready to share.</div>';
});

init();
